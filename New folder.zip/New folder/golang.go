Explain
// First Go program
package main

import &quot;fmt&quot;

// Main function
func main() {

    fmt.Println(&quot;!... Hello World ...!&quot;)
}
